<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package itfarm
 */

if ( ! is_active_sidebar( 'sidebar-1' ) ) {
	return;
}
?>

<aside id="secondary" class="widget-area custom-sidebar">
	<?php dynamic_sidebar( 'sidebar-1' ); ?>

	<div class="follow-sidebar mb-4">
		<h3 class="sidebar-title">Follow Us</h3>
		<ul>
			<li><a href="https://www.facebook.com/umangnashamukti"><i class="fa-brands fa-facebook-f"></i>&nbsp;FACEBOOK</a></li>
			<li><a href="https://twitter.com/MuktiUmang"><i class="fa-brands fa-twitter"></i>&nbsp;TWITTER</a></li>
			<li><a href="https://www.instagram.com/accounts/login/"><i class="fa-brands fa-instagram"></i>&nbsp;INSTAGRAM</a></li>
			
		</ul>
	</div>

	<div class="recent-blogss">
	    <h3 class="sidebar-title">TOP POSTS</h3>
	    
		<?php 
		$args = array( 
			'post_type'   => 'post',
			'posts_per_page' => 4,
			'orderby' => 'date',
            'order'   => 'DESC',
		);
		$scheduled = new WP_Query( $args );

		if ( $scheduled->have_posts() ) : 
		?>

	<div class="inside">
		<div class="row">
			<?php while( $scheduled->have_posts() ) : $scheduled->the_post() ?>

				<div class="col-lg-6 mb-4">
					<div class="blog-left-image">
						<a href="<?php echo get_permalink(); ?>"><img src="<?php echo get_the_post_thumbnail_url(); ?>" class="img-fluid"> </a>
					</div>
				</div>
				<div class="align-items-start col-lg-6 d-flex pl-0">

					<div class="right-post-inside">
						<div class="tags-posts">
												<?php
												$posttags = get_the_category(get_the_ID());
												$slug = get_category_link($posttags[0]->term_id);
												if ($posttags) {
												    
												    $listt = "";
												  foreach($posttags as $tag) {
												    $listt .= "<a href='".get_category_link($tag->term_id)."'>".$tag->name . '</a>'; 
												  }
												  
												  echo rtrim($listt, ', ');
												}
												?>
						</div>

						<h6><a href="<?php echo get_permalink(); ?>"><?php the_title(); ?></a></h6>
						<!-- <p class="date-published"><small><?php echo get_the_date(); ?></small></p> -->
						
					</div>
				</div>
				

			<?php endwhile ?>
			</div>
	</div>

		<?php else : ?>
			No Post Found...
		<?php endif ?>
	</div>

</aside><!-- #secondary -->	
